AIMPSoundOutBPM contains source code of the BPM calculator, which based on BPM detection algorithm from the SoundTouch library.
� Olli Parviainen (http://www.surina.net/soundtouch/)

AIMPSoundOutData contains source code of additional classes, which uses in the BPM calculator.